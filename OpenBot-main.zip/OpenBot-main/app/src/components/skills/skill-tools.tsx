import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Field, FieldLabel } from "@/components/ui/field";
import { pluginsPageQueryOptions } from "@/lib/plugins/queries";
import { RESEARCH_ROLES } from "@openbot/shared/research";
import { undeclaredElsewhere } from "@/lib/skills/form";

/**
 * Which tools this skill says it needs.
 *
 * WHY IT MATTERS THAT THIS EXISTS AT ALL. Selection is over skills: before a run the deployment asks
 * its own model which skills the message needs, and the Bot is built with those skills' tools plus
 * every granted tool no skill claims. A deployment where no skill declares anything has nothing to
 * select on, so every Bot is offered its whole catalogue — which is the case the narrowing was built
 * to fix. Until this screen existed the only way to declare a tool was to call the API by hand.
 *
 * A DECLARATION IS NOT A GRANT, and this is the one thing the screen has to get across. Anybody
 * signed in may write a skill; adding an MCP server is an administrator's decision. If naming a tool
 * here made it callable, the first surface would be a way around the second. It does not: the offer
 * is intersected with what the Bot was granted, so a skill naming a tool its Bot does not hold
 * selects the skill and loads nothing. Said in the hint rather than left for somebody to discover,
 * because the failure it prevents is somebody ticking boxes expecting access.
 *
 * PART OF THE FORM, unlike the Agents toggles below it. What a skill needs is the author's draft
 * until they press save, so unticking one and closing the panel changes nothing. Granting is the
 * opposite and saves on press, which is why the two look different on purpose.
 */
export function SkillTools({
  selected,
  onChange,
}: {
  selected: string[];
  onChange: (refs: string[]) => void;
}) {
  const plugins = useQuery(pluginsPageQueryOptions());
  const held = new Set(selected);

  const toggle = (ref: string) => {
    /*
     * Rebuilt rather than mutated, and filtered rather than spliced, so the array handed to the form
     * is a new one. React Form compares by reference; mutating in place leaves the field's value
     * looking unchanged and the submit button disabled on a form the person has edited.
     */
    onChange(
      held.has(ref)
        ? selected.filter((each) => each !== ref)
        : [...selected, ref],
    );
  };

  /*
   * Only servers that actually offer something. A server whose tools have never been refreshed has
   * an empty list, and a heading with nothing under it reads as a tool that failed to draw.
   */
  const servers = (plugins.data?.servers ?? []).filter(
    (server) => server.tools.length > 0,
  );

  /*
   * Declared, and offered by nothing this deployment has connected.
   *
   * Shown rather than dropped, because the alternative is a screen that states part of the
   * declaration as though it were all of it. A package ships skills declaring tools for connectors
   * nobody has added yet, and a person's own skill outlives the server it was written against, so
   * this is the ordinary case rather than a corner of one. Left out, a skill needing two tools drew
   * one and the second was invisible to the person governing it.
   *
   * Only computed once the list has actually loaded: while the query is pending every ref looks
   * unmatched, and flashing the whole declared set into this group and out again would be worse
   * than showing nothing for a moment.
   */
  const elsewhere = plugins.data
    ? undeclaredElsewhere(
        selected,
        servers.flatMap((server) => server.tools.map((tool) => tool.ref)),
      )
    : [];

  return (
    <Field>
      <FieldLabel>Tools it needs</FieldLabel>

      {plugins.isPending ? null : plugins.error ? (
        <p className="text-destructive text-xs" role="alert">
          Couldn't load the tools. Reload the page.
        </p>
      ) : servers.length === 0 ? (
        <p className="text-muted-foreground text-xs">
          No app offers tools yet. You can still write the skill. Most skills
          are only instructions.
        </p>
      ) : (
        <div className="flex flex-col gap-3">
          {servers.map((server) => (
            <div className="flex flex-col gap-1.5" key={server.id}>
              <p className="text-muted-foreground text-xs">{server.title}</p>
              <div className="flex flex-wrap gap-2">
                {server.tools.map((tool) => {
                  const on = held.has(tool.ref);
                  return (
                    <Button
                      key={tool.ref}
                      onClick={() => toggle(tool.ref)}
                      size="sm"
                      /*
                       * The vendor's own tool name, not the namespaced one a model sees. The person
                       * reading this is matching it against the vendor's documentation.
                       */
                      title={tool.description}
                      type="button"
                      variant={on ? "default" : "outline"}
                    >
                      {tool.name}
                      {/*
                       * Writes are marked. Which tools a skill pulls in is a governance question, and
                       * "this one changes something at the vendor" is the part worth seeing before
                       * ticking it rather than after.
                       */}
                      {tool.effect === "write" ? (
                        <span
                          aria-label="changes something"
                          className="ml-1 opacity-60"
                          role="img"
                        >
                          ✎
                        </span>
                      ) : null}
                    </Button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {plugins.data ? (
        <div className="flex flex-col gap-1.5">
          <p className="text-muted-foreground text-xs">Public-web research</p>
          <div className="flex flex-wrap gap-2">
            {RESEARCH_ROLES.map((role) => (
              <Button
                key={role.ref}
                onClick={() => toggle(role.ref)}
                size="sm"
                title={`${role.ref}: uses whichever research app the Bot has`}
                type="button"
                variant={held.has(role.ref) ? "default" : "outline"}
              >
                {role.label}
              </Button>
            ))}
          </div>
        </div>
      ) : null}

      {elsewhere.length > 0 ? (
        <div className="flex flex-col gap-1.5">
          <p className="text-muted-foreground text-xs">Not available here</p>
          <div className="flex flex-wrap gap-2">
            {elsewhere.map((ref) => (
              <Button
                key={ref}
                onClick={() => toggle(ref)}
                size="sm"
                /*
                 * The whole ref, not a tool name. There is no server here to put it under, and the
                 * server id is the part that says which connector is missing.
                 */
                title={`${ref}: no app here offers this`}
                type="button"
                variant="secondary"
              >
                {ref}
              </Button>
            ))}
          </div>
          <p className="text-muted-foreground text-xs">
            This skill asks for these, but no app here offers them. They do
            nothing until an admin adds the app. Click one to remove it.
          </p>
        </div>
      ) : null}

      <p className="text-muted-foreground text-xs">
        Using this skill loads these tools for that reply. It doesn't give
        access. A Bot can only use tools it already has.
      </p>
    </Field>
  );
}
